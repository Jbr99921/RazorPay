- [ ] I have gone through the README.(https://github.com/razorpay/razorpay-pod)
- [ ] I have searched for a similar issue (https://github.com/razorpay/razorpay-pod/issues)
- [ ] I am using the latest version of our framework (https://github.com/razorpay/razorpay-pod/releases)
- [ ] I have cleaned my project , deleted derived data and rebuilt it.

<!-- Describe your issue in detail. -->

## IDE Specs
<!-- Required. Specify your Xcode Version , Razorpay Package Version -->

## Retro Steps
<!-- 
  Required.
-->

## Screenshots 
<!-- Optional.It'll just help us understand your issue better. -->
